# FlightOps — an AI Operations Officer for AeroWing Airlines

Assignment 04, *Agentic AI: From Concepts to Practice*.

This is the tool-calling agent version of AeroBrain. Instead of just retrieving
text and answering from it, it decides which internal functions to call, in
what order, runs them itself, and reasons over whatever comes back before
answering.

No LangChain, CrewAI, AutoGen, or MCP — the tool loop, planner, and reflector
are just plain Python control flow.

---

## Model provider

| | |
|---|---|
| Provider | Google Gemini (`google-genai` SDK) |
| Model | `gemini-3.6-flash` (override with `GEMINI_MODEL`) |
| Provider-specific code | `llm.py` only |

`llm.py` is the single file that imports the SDK. Everything above it speaks in a
neutral transcript format (`{"role": "user" | "model" | "tool", ...}`) and a
neutral `ModelReply` object. Supporting OpenAI or Anthropic means adding one more
adapter class with a `respond()` method and returning it from `get_model()`;
`agent.py`, `planner.py` and `reflector.py` would not change a line.

Automatic function calling in the SDK is explicitly **disabled**. The library is
perfectly willing to execute Python callables on the model's behalf, and that is
exactly the thing this assignment is about not doing.

---

## Running it

```bash
pip install -r requirements.txt
cp .env.example .env          # then paste your key into .env
```

```bash
python app.py                 # Part 1: exercise all six tools, no model involved
python test_offline.py        # drive the whole agent loop with a scripted stub, no API key
python main.py                # interactive operations session
python main.py "Is AI203 likely to depart on time?"
python main.py --demo         # the three scenarios used for the screenshots
python main.py --lazy "..."          # Part 2: degraded tool description
python main.py --minimal-tools "..." # Part 4 exploration: only 3 of 6 tools
```

`app.py` and `test_offline.py` need no API key. Run them first — if a tool is
broken, you want to find out there rather than inside a confusing conversation
with the model.

---

## Files

| File | Responsibility |
|---|---|
| `data.py` | Mock AeroWing databases: flights, aircraft types, passengers, maintenance records, weather observations, gate occupancy. Plain dicts, no logic. |
| `tools.py` | The six callable functions, plus `TOOL_REGISTRY` and `run_tool()`. Every tool returns a dict with `status: ok` or `status: error`; the `@tool` decorator guarantees no exception ever escapes. |
| `schemas.py` | The tool declarations the model actually sees — name, description, parameters, required fields — as provider-neutral dicts. Also holds the lazy/careful description pair and the reduced toolset for the Part 4 exploration. |
| `llm.py` | The only provider-aware file. Translates the neutral transcript into Gemini `Content`/`Part` objects and normalises the response into `ModelReply(text, tool_calls)`. |
| `agent.py` | The function-calling loop. Sends the conversation with declarations attached, receives tool requests, dispatches them through `tools.run_tool`, appends results, repeats until the model answers in prose. Records every call as a `ToolInvocation`. |
| `planner.py` | Part 5. One tool-free model call before execution that produces a Goal and a numbered Plan, parsed into a `Plan` object. |
| `reflector.py` | Part 6. One tool-free model call after the answer, shown the full call log, asked to criticise its own run under four fixed headings. |
| `trace.py` | Console rendering of Goal → Plan → Tool → Observation → Answer → Reflection. Kept apart from `agent.py`, which emits events rather than printing. |
| `config.py` | Environment loading. The only file that touches `os.environ`. |
| `app.py` | Part 1 test harness: calls every tool directly, happy paths and failure paths. |
| `test_offline.py` | Drives the full agent loop with a scripted stand-in model, asserting that chaining, error handling and the planner/reflector wiring all behave. Runs with no key and no network. |
| `main.py` | Entry point: argument parsing, interactive session, demo scenarios. |

### The loop, in short

```
transcript = [user question]
repeat up to MAX_TOOL_ROUNDS:
    reply = model.respond(transcript, declarations)
    if reply has no tool calls:
        return reply.text
    append the model's turn (tool requests included) to the transcript
    for each requested call:
        result = tools.run_tool(name, arguments)   # our code, not the model's
        append the result to the transcript
```

Two things tripped me up while getting this working. Gemini rejects a function
response if you haven't first appended the model's own turn (the one that asked
for the tool) — I hit that error a few times before I got the ordering right.
The other one is the round cap: without `MAX_TOOL_ROUNDS`, a confused model
just keeps requesting tools until the quota runs out. When it hits the cap,
FlightOps makes one last call with the tools stripped out and asks for
whatever answer it can give with what it's already got.

---

## Example prompts

| Prompt | Expected shape |
|---|---|
| `Is AI203 likely to depart on time?` | Three-tool chain: status → weather → maintenance |
| `Is the aircraft on AI417 fit to fly, and if not, what is the impact?` | Status → maintenance, finds grounding defect MX-4390 |
| `Find me an empty gate in T3 and tell me which flights are holding the others` | Single tool |
| `What is the weather at CCU right now, and is AI556 affected by it?` | Failing tool, handled gracefully |
| `Pull the maintenance record for the aircraft on flight AI203` | Must resolve flight → tail number first |
| `What seat is Roopa Nair in?` | Single tool; should *not* call the flight tools |

---

## Part 2 — lazy vs careful descriptions

The same tool, described two ways (`schemas.py`):

```python
LAZY_FLIGHT_STATUS_DESCRIPTION = "Gets flight info."

CAREFUL_FLIGHT_STATUS_DESCRIPTION = (
    "Returns today's live operational record for one specific flight number: "
    "current status ... Use the returned tail_number as the input to "
    "maintenance_history, and the returned origin as the input to get_weather. "
    "This tool does not know about weather or maintenance."
)
```

The lazy version just doesn't give the model enough to go on. The careful one
spells out what comes back (so the model knows this is where you get a tail
number from), when to use it (so it stops competing with `lookup_aircraft`),
and — this is the part that actually mattered when I tested it — what it does
*not* cover, so the model doesn't stop after one status call and treat that as
a full answer to a delay question.

Careful description (`python main.py "Pull the maintenance record for the aircraft on flight AI203"`):

```
Tool sequence : get_flight_status -> maintenance_history
Model rounds  : 3
Tool calls    : 2 (0 returned an error)
```

Lazy description (`python main.py --lazy "Pull the maintenance record for the aircraft on flight AI203"`):

```
Tool sequence : get_flight_status -> maintenance_history
Model rounds  : 3
Tool calls    : 2 (0 returned an error)
```

Same sequence both times, which surprised me — I expected the lazy version to
either skip `get_flight_status` or stop after it. Looking at it afterwards,
the reason is the question itself does most of the work: "the aircraft *on
flight* AI203" already tells the model it needs to resolve a flight number to
an aircraft before it can look up maintenance, so even a description as thin
as "Gets flight info." is enough when the prompt hands over that reasoning
for free. I'd expect the lazy description to actually cause damage on a
vaguer prompt — something like "check on AI203" — where the model has to
supply that reasoning itself instead of reading it off the question. The
gap between the two descriptions is in what's *not* being tested here: the
lazy one gives no hint that `get_flight_status` doesn't cover weather or
maintenance, which is exactly the guardrail that matters for Part 4's
three-tool question, not this one.

---

## Part 4 — multi-tool run

Actual run (`python main.py "Is AI203 likely to depart on time?"`):

```
RUN SUMMARY
===========
Tool sequence : get_flight_status -> maintenance_history -> get_weather
Model rounds  : 3
Tool calls    : 3 (0 returned an error)
```

Matches `screenshots/part4.png`.

I set this scenario up so no single tool can actually answer it. `get_flight_status`
on AI203 comes back `Scheduled`, `delay_minutes: 0` — so if the model stops
there, it gives a confident, wrong "yes, on time." The real reasons live
elsewhere: DEL is sitting at 550m visibility in fog, and the aircraft (VT-AWA)
has an open defect, MX-4417. You genuinely need all three tools to answer this
properly. There's also a wrinkle I put in on purpose — the maintenance item is
a deferred APU bleed valve, which is *not* a grounding issue, so a good answer
has to notice that too instead of just dumping every finding on the user.

### Exploration: does having more tools hurt?

> **TODO:** run the same question both ways and compare.
>
> ```bash
> python main.py "Is AI203 likely to depart on time?"
> python main.py --minimal-tools "Is AI203 likely to depart on time?"
> ```
>
> Things worth recording: total rounds, whether `lookup_aircraft` gets called
> despite being irrelevant, and whether the three-tool version converges faster.

---

## Part 7 — error handling

I wired in two failure paths, both return structured errors instead of blowing up:

- **Service outage.** `CCU` is listed in `WEATHER_SERVICE_OUTAGE`, so the fake
  METAR fetch throws a `ConnectionError`. The tool catches it and hands back
  `{"status": "error", "message": "Weather service unavailable ..."}` instead
  of crashing.
- **Bad input.** `maintenance_history` checks the tail number against a
  registration pattern, because models like to pass a flight number here
  instead — happened to me a couple of times during testing — and that now
  gets a real error message back instead of a `KeyError`.

Either way, the error just gets appended to the transcript like any other tool
result. The system prompt tells the model not to retry more than once and not
to make up the missing value, so the user actually gets told which check
failed instead of getting a confident guess.

---

## Final Report

**1. Retrieval grounding vs tool-calling grounding — what changes about the risk?**

With retrieval, if you get the wrong passage you get a wrong sentence — and you
can usually catch it, because the citation is right there and you can check
whether the quoted text actually backs up the claim. Tool calling doesn't give
you that. The answer looks exactly the same whether the agent checked three
systems or just one, so a missing check is basically invisible — nothing in
the output tells you a check didn't happen. It's not even that the tool
returns nothing; `get_flight_status("AI203")` happily returns `Scheduled`,
full stop, and the model has zero signal that there's fog at the airport or an
open defect on the aircraft, because it never touched those systems. And the
risk gets worse once tools can write, not just read — a bad grounding
decision isn't just a bad answer anymore, it's a bad action that already
happened.

**2. A function and its declaration drift apart — what happens, and how do you catch it?**

The model only ever sees the declaration, not the real function signature, so
if you rename a parameter in the code and forget the schema, the model keeps
sending the old name in good faith and Python throws `TypeError: got an
unexpected keyword argument`. If nothing catches that, the whole agent loop
just dies mid-conversation. I made `run_tool` catch `TypeError` specifically
so the model at least gets back "Bad arguments for maintenance_history" and
can tell the user the lookup failed, instead of the process crashing outright.
The scarier version of this bug is when both the old and new name still work,
or the description just quietly stops matching what the function actually
does — then you don't get an error at all, you get a plausible-sounding wrong
answer, which is a lot harder to catch. Cheapest fix I can think of: a startup
check that diffs each declaration's parameters against `inspect.signature()`
of the real function and refuses to boot if they don't line up. Basically a
contract test between the schema and the code — didn't get to add it here, but
I'd want it before this ever touched real systems.

**3. What changes when FlightOps can cancel a booking or reassign a gate?**

Right now every tool in this project only reads — worst case, a wrong
`get_weather` call wastes a few tokens and that's it. `cancel_booking` is a
different animal: get that wrong and a passenger is actually stranded, and no
amount of reflecting afterwards fixes that. It also stops being just an
accuracy problem and becomes an authority problem — the model sounds exactly
as confident whether it's 95% sure or 55% sure, so if it's willing to guess a
tail number, it's just as willing to guess which booking to cancel. Prompt
injection gets scarier too, because now a passenger name or a maintenance note
isn't just data the agent reads, it's a potential instruction. If I were
actually shipping this, I'd split tools into separate read and write
registries, require a human to explicitly confirm every write with the exact
arguments shown on screen, log the reasoning behind every write action, and
scope credentials tightly enough that the agent physically can't touch a
booking nobody asked about.

**4. Descriptions or system prompt — which mattered more?**

I ran `"Is AI203 likely to depart on time?"` three ways: (a) full system
prompt + careful description, (b) the "Chain tools when a question needs
it..." line deleted from the system prompt, careful description kept, (c)
system prompt restored, `--lazy` description instead. All three produced the
exact same result: `get_flight_status -> maintenance_history -> get_weather`,
3 tool calls, 3 rounds, correct "not on time, fog at DEL" answer.

That surprised me — I expected at least one of the two ablations to break the
chain, and going in I'd guessed the system prompt would matter more for *how
many* tools get chained. It didn't hold up. What I think is actually going on:
this particular question is redundantly over-specified. "Depart on time"
pulls in weather and status by itself, the careful description spells out the
tail_number/origin handoff regardless of what the system prompt says, and the
model clearly has enough background aviation knowledge (fog → visibility →
delay) to fill in gaps neither one covers. So for *this* question, removing
either lever on its own wasn't enough to break tool selection — it took a
genuinely vague question (see Part 2, where the lazy description also didn't
move the needle for the same reason) to see any effect at all. My revised
guess is that these two levers only start to matter independently once the
question itself stops doing so much of the reasoning for the model — a
worthwhile thing to test further with a deliberately ambiguous prompt, but
that's an experiment for another pass at this, not this one.

---

## Screenshots

`screenshots/` should contain:

- `part4.png` — a multi-tool run with the plan and reflection visible
- `part7.png` — the agent handling the failing weather tool gracefully

Both come from `python main.py --demo`.

---


