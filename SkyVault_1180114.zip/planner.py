"""Part 5: decide what the answer will require before any tool runs.

The plan is not an execution script - the agent loop is free to diverge from it.
It exists so an operations officer reading the output can see why FlightOps
checked what it checked.
"""

import re
from dataclasses import dataclass, field

PLANNER_SYSTEM_PROMPT = """You are the planning module of FlightOps, an AI \
operations officer for AeroWing Airlines.

You do not answer the user's question and you do not call any tools. You write \
the plan that another module will carry out.

These tools will be available to the executor:
{tool_summary}

Reply in exactly this format and nothing else:

Goal: <one sentence describing what a complete answer must establish>
Plan:
1. <step>
2. <step>
3. <step>

Rules:
- Between one and five steps.
- Each step should name the tool it expects to use, in parentheses, unless the \
step is pure synthesis.
- Order matters: if one tool's output feeds another's input, say so.
- Operational questions about whether a flight can depart normally need weather, \
maintenance and flight status together, not just one of them.
"""


@dataclass
class Plan:
    goal: str
    steps: list[str] = field(default_factory=list)
    raw: str = ""

    def as_prompt_hint(self) -> str:
        """A compact form of the plan to hand to the executing agent."""
        if not self.steps:
            return ""
        numbered = "\n".join(f"{i}. {s}" for i, s in enumerate(self.steps, 1))
        return f"Goal: {self.goal}\nPlan:\n{numbered}"


def make_plan(model, question: str, declarations: list[dict]) -> Plan:
    """Ask the model for a goal and a numbered plan, with no tools attached."""
    tool_summary = "\n".join(
        f"- {d['name']}: {d['description'].split('.')[0]}." for d in declarations
    )
    system_prompt = PLANNER_SYSTEM_PROMPT.format(tool_summary=tool_summary)

    reply = model.respond(
        transcript=[{"role": "user", "text": question}],
        declarations=None,
        system_instruction=system_prompt,
        temperature=0.2,
    )

    return _parse_plan(reply.text, question)


def _parse_plan(text: str, question: str) -> Plan:
    """Pull the goal and steps out of the model's reply, tolerating stray markdown."""
    cleaned = text.replace("**", "").strip()

    goal_match = re.search(r"Goal\s*:\s*(.+)", cleaned)
    goal = goal_match.group(1).strip() if goal_match else f"Answer: {question}"

    steps = [
        line.strip()
        for line in re.findall(r"^\s*\d+[.)]\s*(.+)$", cleaned, flags=re.MULTILINE)
    ]

    return Plan(goal=goal, steps=steps, raw=cleaned)
