"""ROLL NUMBER: 1180114

MCP Server: the standard protocol layer that wraps tools.py.

Implements the Model Context Protocol's three core message types:
  - initialize: handshake exchanging name and protocol version
  - tools/list: returns available tools with their descriptions and schemas
  - tools/call: executes a named tool with given arguments

All messages are JSON-RPC 2.0 shaped dictionaries with jsonrpc version, id,
method, params, and responses with result or error fields.
"""

import json
from typing import Any


class ToolRegistry:
    """Registry of available tools, decoupled from how they are exposed."""

    def __init__(self):
        self.tools = {}

    def register(
        self,
        name: str,
        func,
        description: str,
        parameters: dict,
    ):
        """Register a tool with its metadata.

        Args:
            name: unique tool name (e.g., "get_flight_status")
            func: callable that executes the tool
            description: human-readable description for the model
            parameters: JSON Schema object describing the tool's arguments
        """
        self.tools[name] = {
            "name": name,
            "func": func,
            "description": description,
            "parameters": parameters,
        }

    def get_tool(self, name: str):
        """Return the tool function by name, or None if not found."""
        tool = self.tools.get(name)
        return tool["func"] if tool else None

    def list_tools(self) -> list[dict]:
        """Return metadata for all registered tools (no func field)."""
        result = []
        for name, tool in self.tools.items():
            result.append(
                {
                    "name": tool["name"],
                    "description": tool["description"],
                    "parameters": tool["parameters"],
                }
            )
        return result

    def call_tool(self, name: str, arguments: dict) -> dict:
        """Execute a tool by name with given arguments.

        Returns the tool's result dict, or a JSON-RPC error object if the tool
        is unknown or arguments don't match the schema.
        """
        tool = self.tools.get(name)
        if not tool:
            return {
                "status": "error",
                "message": f"Unknown tool: {name}. Available: {', '.join(self.tools)}",
            }

        func = tool["func"]
        try:
            result = func(**arguments)
            return result
        except TypeError as exc:
            return {
                "status": "error",
                "tool": name,
                "message": f"Bad arguments for {name}: {exc}",
            }


class MCPServer:
    """MCP Server: handles initialize, tools/list, and tools/call messages."""

    def __init__(self, registry: ToolRegistry, name: str = "SkyVault", version: str = "1.0"):
        self.registry = registry
        self.name = name
        self.version = version

    def handle_request(self, request: dict) -> dict:
        """Process a JSON-RPC request and return a response.

        Args:
            request: a dict with jsonrpc, id, method, and params

        Returns:
            a dict with jsonrpc, id, and either result or error
        """
        jsonrpc = request.get("jsonrpc", "2.0")
        request_id = request.get("id")
        method = request.get("method")
        params = request.get("params", {})

        if not request_id:
            return {"jsonrpc": "2.0", "error": {"code": -32600, "message": "Missing id"}}

        if method == "initialize":
            return self._handle_initialize(request_id, params)
        elif method == "tools/list":
            return self._handle_tools_list(request_id)
        elif method == "tools/call":
            return self._handle_tools_call(request_id, params)
        else:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {"code": -32601, "message": f"Unknown method: {method}"},
            }

    def _handle_initialize(self, request_id: Any, params: dict) -> dict:
        """Initialize handshake. Exchange client/server name and version."""
        client_name = params.get("client_name", "unknown")
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {
                "server_name": self.name,
                "server_version": self.version,
                "protocol_version": "1.0",
                "capabilities": {"tools": True},
            },
        }

    def _handle_tools_list(self, request_id: Any) -> dict:
        """Return the list of available tools."""
        tools = self.registry.list_tools()
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": {"tools": tools},
        }

    def _handle_tools_call(self, request_id: Any, params: dict) -> dict:
        """Execute a named tool with given arguments."""
        name = params.get("name")
        arguments = params.get("arguments", {})

        if not name:
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {"code": -32602, "message": "Missing tool name in params"},
            }

        result = self.registry.call_tool(name, arguments)

        if result.get("status") == "error":
            # Tool execution failed - return a JSON-RPC error
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32001,
                    "message": result.get("message", "Tool execution failed"),
                },
            }

        # Tool succeeded - return its result as the response result
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": result,
        }
