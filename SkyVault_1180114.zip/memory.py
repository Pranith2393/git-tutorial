"""ROLL NUMBER: 1180114

Persistent memory store for SkyVault.

Facts written in one session survive a process restart, loaded back into the
system prompt at startup. The model can also call remember/recall mid-conversation
to store and retrieve facts learned during execution.

Conflict resolution rule: if a fact with the same key is restated with a different
value, the new value overwrites the old. This is "last-write-wins" semantics, chosen
because operational facts (weather, aircraft status, gate assignments) are time-sensitive
and the most recent observation should be trusted.
"""

import json
from pathlib import Path
from datetime import datetime


MEMORY_FILE = Path(__file__).resolve().parent / "memory.json"


def _load_memory() -> dict:
    """Load facts from disk, or return empty dict if file does not exist."""
    if not MEMORY_FILE.exists():
        return {}
    try:
        with open(MEMORY_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}


def _save_memory(facts: dict) -> None:
    """Write facts to disk."""
    with open(MEMORY_FILE, "w") as f:
        json.dump(facts, f, indent=2)


def remember(key: str, value, source: str = "agent") -> dict:
    """Store a fact. Overwrites any previous fact with the same key.

    Args:
        key: unique identifier for the fact (e.g., "terminal_preference")
        value: any JSON-serializable value
        source: who provided this fact (e.g., "user", "agent", "tool")

    Returns:
        {"status": "ok", "key": key, "message": "..."}
    """
    facts = _load_memory()

    old_value = facts.get(key, {}).get("value") if key in facts else None

    facts[key] = {
        "value": value,
        "source": source,
        "timestamp": datetime.utcnow().isoformat(),
    }

    _save_memory(facts)

    if old_value is not None and old_value != value:
        return {
            "status": "ok",
            "key": key,
            "message": f"Updated {key}: was {old_value}, now {value}",
        }
    else:
        return {
            "status": "ok",
            "key": key,
            "message": f"Remembered: {key} = {value}",
        }


def recall(query: str) -> dict:
    """Retrieve facts matching a query. Query is a substring search on keys.

    Args:
        query: substring to search for in stored keys (case-insensitive)

    Returns:
        {"status": "ok", "matches": {...}} or {"status": "ok", "matches": {}} if none found
    """
    facts = _load_memory()
    query_lower = query.strip().lower()

    matches = {}
    for key, fact in facts.items():
        if query_lower in key.lower():
            matches[key] = fact["value"]

    if not matches:
        return {
            "status": "ok",
            "matches": {},
            "message": f"No facts found matching '{query}'",
        }

    return {
        "status": "ok",
        "matches": matches,
        "message": f"Found {len(matches)} fact(s) matching '{query}'",
    }


def load_memory_summary() -> str:
    """Return a brief summary of all facts currently in memory for the system prompt.

    If memory is empty, return an empty string (no need to mention it to the model).
    """
    facts = _load_memory()
    if not facts:
        return ""

    summary_lines = ["[Recalled from persistent memory:"]
    for key, fact in sorted(facts.items()):
        summary_lines.append(f"  - {key}: {fact['value']}")
    summary_lines.append("]")

    return "\n".join(summary_lines)
