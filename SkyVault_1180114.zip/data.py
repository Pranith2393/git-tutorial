"""Mock AeroWing operational databases.

Stands in for the flight, maintenance, gate, passenger and weather systems that
a real airline would expose over separate internal APIs. Everything is a plain
dict so the tools in tools.py stay easy to read and easy to test.

All times are local to the airport in question, 24-hour clock, for 2026-08-20.
"""

FLIGHTS = {
    "AI203": {
        "flight_number": "AI203",
        "tail_number": "VT-AWA",
        "aircraft_type": "A320",
        "origin": "DEL",
        "destination": "BOM",
        "scheduled_departure": "14:20",
        "estimated_departure": "14:20",
        "status": "Scheduled",
        "gate": "B12",
        "terminal": "T3",
        "delay_minutes": 0,
    },
    "AI417": {
        "flight_number": "AI417",
        "tail_number": "VT-AWB",
        "aircraft_type": "B737-800",
        "origin": "DEL",
        "destination": "BLR",
        "scheduled_departure": "15:05",
        "estimated_departure": "16:20",
        "status": "Delayed",
        "gate": "B14",
        "terminal": "T3",
        "delay_minutes": 75,
    },
    "AI882": {
        "flight_number": "AI882",
        "tail_number": "VT-AWC",
        "aircraft_type": "A350-900",
        "origin": "BOM",
        "destination": "LHR",
        "scheduled_departure": "02:40",
        "estimated_departure": "02:40",
        "status": "Boarding",
        "gate": "A04",
        "terminal": "T2",
        "delay_minutes": 0,
    },
    "AI556": {
        "flight_number": "AI556",
        "tail_number": "VT-AWD",
        "aircraft_type": "ATR72-600",
        "origin": "CCU",
        "destination": "IXB",
        "scheduled_departure": "09:15",
        "estimated_departure": "09:15",
        "status": "Departed",
        "gate": "C07",
        "terminal": "T1",
        "delay_minutes": 0,
    },
}

AIRCRAFT = {
    "A320": {
        "type": "A320",
        "manufacturer": "Airbus",
        "length_m": 37.6,
        "wingspan_m": 35.8,
        "max_seats": 180,
        "mtow_kg": 78000,
        "fuel_capacity_l": 24210,
        "range_km": 6100,
    },
    "B737-800": {
        "type": "B737-800",
        "manufacturer": "Boeing",
        "length_m": 39.5,
        "wingspan_m": 35.8,
        "max_seats": 189,
        "mtow_kg": 79010,
        "fuel_capacity_l": 26020,
        "range_km": 5765,
    },
    "A350-900": {
        "type": "A350-900",
        "manufacturer": "Airbus",
        "length_m": 66.8,
        "wingspan_m": 64.8,
        "max_seats": 325,
        "mtow_kg": 280000,
        "fuel_capacity_l": 141000,
        "range_km": 15000,
    },
    "ATR72-600": {
        "type": "ATR72-600",
        "manufacturer": "ATR",
        "length_m": 27.2,
        "wingspan_m": 27.1,
        "max_seats": 78,
        "mtow_kg": 23000,
        "fuel_capacity_l": 6390,
        "range_km": 1528,
    },
}

PASSENGERS = [
    {
        "name": "Roopa Nair",
        "booking_ref": "AW7Q2X",
        "seat": "14C",
        "flight_number": "AI203",
        "destination": "BOM",
        "checked_in": True,
    },
    {
        "name": "Imran Sheikh",
        "booking_ref": "AW4KD9",
        "seat": "02A",
        "flight_number": "AI882",
        "destination": "LHR",
        "checked_in": True,
    },
    {
        "name": "Meera Krishnan",
        "booking_ref": "AW1LP5",
        "seat": "22F",
        "flight_number": "AI417",
        "destination": "BLR",
        "checked_in": False,
    },
    {
        "name": "Daniel Fernandes",
        "booking_ref": "AW8ZT3",
        "seat": "09D",
        "flight_number": "AI203",
        "destination": "BOM",
        "checked_in": False,
    },
]

MAINTENANCE = {
    "VT-AWA": {
        "tail_number": "VT-AWA",
        "aircraft_type": "A320",
        "last_inspection": "2026-08-02",
        "next_inspection_due": "2026-09-02",
        "hours_flown": 18422,
        "open_issues": [
            {
                "id": "MX-4417",
                "description": "APU bleed valve intermittent; MEL deferral in effect",
                "severity": "minor",
                "grounding": False,
            }
        ],
        "airworthy": True,
    },
    "VT-AWB": {
        "tail_number": "VT-AWB",
        "aircraft_type": "B737-800",
        "last_inspection": "2026-07-11",
        "next_inspection_due": "2026-08-11",
        "hours_flown": 26310,
        "open_issues": [
            {
                "id": "MX-4390",
                "description": "No.2 engine oil pressure sensor replacement pending",
                "severity": "major",
                "grounding": True,
            }
        ],
        "airworthy": False,
    },
    "VT-AWC": {
        "tail_number": "VT-AWC",
        "aircraft_type": "A350-900",
        "last_inspection": "2026-08-15",
        "next_inspection_due": "2026-09-15",
        "hours_flown": 9114,
        "open_issues": [],
        "airworthy": True,
    },
    "VT-AWD": {
        "tail_number": "VT-AWD",
        "aircraft_type": "ATR72-600",
        "last_inspection": "2026-08-09",
        "next_inspection_due": "2026-09-09",
        "hours_flown": 31207,
        "open_issues": [],
        "airworthy": True,
    },
}

WEATHER = {
    "DEL": {
        "airport": "DEL",
        "conditions": "Dense fog",
        "visibility_m": 550,
        "wind": "040/06 kt",
        "temperature_c": 24,
        "observed_at": "13:50",
    },
    "BOM": {
        "airport": "BOM",
        "conditions": "Light rain",
        "visibility_m": 4000,
        "wind": "250/14 kt",
        "temperature_c": 28,
        "observed_at": "13:50",
    },
    "BLR": {
        "airport": "BLR",
        "conditions": "Scattered cloud",
        "visibility_m": 9000,
        "wind": "270/08 kt",
        "temperature_c": 26,
        "observed_at": "13:50",
    },
    "LHR": {
        "airport": "LHR",
        "conditions": "Overcast",
        "visibility_m": 8000,
        "wind": "210/12 kt",
        "temperature_c": 17,
        "observed_at": "13:50",
    },
}

# Terminal -> gate -> occupying flight (None means the gate is free).
GATES = {
    "T1": {"C05": "AI556", "C06": None, "C07": None},
    "T2": {"A03": "AI882", "A04": "AI882", "A05": None},
    "T3": {"B10": None, "B12": "AI203", "B14": "AI417", "B16": None},
}

# Part 7: the weather feed for these airports is "down" so the agent has to cope
# with a tool that fails rather than one that merely returns nothing.
WEATHER_SERVICE_OUTAGE = {"CCU"}
