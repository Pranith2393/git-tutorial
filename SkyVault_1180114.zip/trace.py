"""Console rendering of one agent run.

Goal -> Plan -> Tool -> Observation -> ... -> Answer -> Reflection

Kept separate from agent.py so the agent stays printable-agnostic: it emits
events, this file decides what they look like.
"""

import json
import textwrap

WIDTH = 78


def rule(title: str = "") -> None:
    if title:
        print(f"\n{title}\n{'=' * min(len(title), WIDTH)}")
    else:
        print("-" * WIDTH)


def wrap(text: str, indent: str = "") -> str:
    paragraphs = [p.strip() for p in text.split("\n") if p.strip()]
    return "\n".join(
        textwrap.fill(
            p,
            width=WIDTH,
            initial_indent=indent,
            subsequent_indent=indent,
        )
        for p in paragraphs
    )


def show_question(question: str) -> None:
    rule("QUESTION")
    print(wrap(question))


def show_plan(plan) -> None:
    rule("GOAL")
    print(wrap(plan.goal))
    rule("PLAN")
    if plan.steps:
        for i, step in enumerate(plan.steps, 1):
            print(
                textwrap.fill(
                    step,
                    width=WIDTH,
                    initial_indent=f"{i}. ",
                    subsequent_indent="   ",
                )
            )
    else:
        print(wrap(plan.raw or "(the planner returned no usable steps)"))


def show_thought(text: str) -> None:
    print(f"\n  [model] {textwrap.shorten(text, width=WIDTH - 10)}")


def show_tool_request(call) -> None:
    arguments = json.dumps(call.arguments, default=str)
    print(f"\n  TOOL   -> {call.name}({arguments})")


def show_observation(invocation) -> None:
    marker = "ERROR " if invocation.failed else "OBSERV"
    payload = json.dumps(invocation.result, default=str)
    if len(payload) > 340:
        payload = payload[:340] + " ...}"
    print(f"  {marker} <- {payload}")
    print(f"           ({invocation.duration_ms:.1f} ms)")


def show_answer(text: str) -> None:
    rule("ANSWER")
    print(wrap(text))


def show_reflection(text: str) -> None:
    rule("REFLECTION")
    print(wrap(text))


def show_summary(run) -> None:
    rule("RUN SUMMARY")
    sequence = " -> ".join(c.name for c in run.tool_calls) or "(no tools called)"
    failures = sum(1 for c in run.tool_calls if c.failed)
    print(f"Tool sequence : {sequence}")
    print(f"Model rounds  : {run.rounds_used}")
    print(f"Tool calls    : {len(run.tool_calls)} ({failures} returned an error)")
    if run.hit_round_limit:
        print("Note          : stopped at the round limit and answered with what it had.")
    print()
