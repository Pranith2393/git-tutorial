"""Configuration loaded from the environment.

Nothing else in the project reads os.environ directly, so switching providers
or models is a one-file change.
"""

import os
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent
ENV_FILE = PROJECT_ROOT / ".env"

load_dotenv(ENV_FILE)

PROVIDER = os.getenv("LLM_PROVIDER", "gemini")
MODEL = os.getenv("GEMINI_MODEL", "gemini-3.6-flash")
API_KEY = os.getenv("GEMINI_API_KEY")

# The agent loop stops after this many round trips even if the model keeps
# asking for tools. Without it, a confused model can loop until the quota runs out.
MAX_TOOL_ROUNDS = int(os.getenv("MAX_TOOL_ROUNDS", "8"))


def require_api_key() -> str:
    """Return the API key, or explain how to set it instead of failing cryptically."""
    if not API_KEY:
        raise SystemExit(
            "GEMINI_API_KEY is not set.\n"
            f"Copy .env.example to {ENV_FILE} and fill in your key, "
            "or export the variable in your shell."
        )
    return API_KEY
