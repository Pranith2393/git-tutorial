"""Part 1 harness: exercise every tool directly, with no model involved.

Run this first. If something is broken here, you want to find out now rather
than halfway through a confusing conversation with the LLM.

    python app.py
"""

import json

import tools

CHECKS = [
    ("get_flight_status", {"flight_number": "AI203"}),
    ("get_flight_status", {"flight_number": "ai417"}),
    ("get_flight_status", {"flight_number": "XX999"}),
    ("search_passenger", {"name": "Roopa"}),
    ("search_passenger", {"name": "Nobody"}),
    ("maintenance_history", {"tail_number": "VT-AWA"}),
    ("maintenance_history", {"tail_number": "VT-AWB"}),
    ("maintenance_history", {"tail_number": "not-a-tail"}),
    ("find_available_gate", {"terminal": "T3"}),
    ("find_available_gate", {"terminal": "9"}),
    ("get_weather", {"airport": "DEL"}),
    ("get_weather", {"airport": "CCU"}),
    ("lookup_aircraft", {"aircraft_type": "a320"}),
    ("lookup_aircraft", {"aircraft_type": "Concorde"}),
    ("no_such_tool", {}),
]


def main() -> None:
    passed = failed = 0

    for name, arguments in CHECKS:
        result = tools.run_tool(name, arguments)
        outcome = result.get("status", "?")
        if outcome == "ok":
            passed += 1
        else:
            failed += 1

        printable = json.dumps(result, indent=2, default=str)
        if len(printable) > 600:
            printable = printable[:600] + "\n  ... (truncated)"

        print(f"\n{name}({arguments}) -> {outcome}")
        print(printable)

    print(f"\n{'-' * 60}")
    print(f"{passed} calls returned ok, {failed} returned a structured error.")
    print("Every error above is expected: none of them raised.")


if __name__ == "__main__":
    main()
