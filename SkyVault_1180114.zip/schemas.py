"""ROLL NUMBER: 1180114

Tool declarations: what the model is told about each function in tools.py.

These are plain dicts in the OpenAPI-subset shape that every major provider
accepts, so nothing here is Gemini-specific. llm.py wraps them in whatever
object the SDK wants.

The model never sees the Python source. Its only view of a tool is the name,
the description, and the parameter descriptions below, which is why the wording
matters as much as the implementation.
"""

from copy import deepcopy

# Part 2 experiment: the same tool described two ways. Swap between them with
# `python main.py --lazy` to see how tool selection changes.
LAZY_FLIGHT_STATUS_DESCRIPTION = "Gets flight info."

CAREFUL_FLIGHT_STATUS_DESCRIPTION = (
    "Returns today's live operational record for one specific flight number: "
    "current status (Scheduled, Boarding, Delayed, Departed), scheduled and "
    "estimated departure times, delay in minutes, assigned gate and terminal, "
    "and the tail number and type of the aircraft operating it. Use this when "
    "the user names a flight, e.g. 'AI203'. Use the returned tail_number as the "
    "input to maintenance_history, and the returned origin as the input to "
    "get_weather. This tool does not know about weather or maintenance."
)

DECLARATIONS = [
    {
        "name": "get_flight_status",
        "description": CAREFUL_FLIGHT_STATUS_DESCRIPTION,
        "parameters": {
            "type": "object",
            "properties": {
                "flight_number": {
                    "type": "string",
                    "description": "IATA flight number, e.g. 'AI203'.",
                }
            },
            "required": ["flight_number"],
        },
    },
    {
        "name": "search_passenger",
        "description": (
            "Looks up a passenger on today's manifests by full or partial name and "
            "returns their booking reference, seat, flight number, destination and "
            "check-in state. Use this only when the user asks about a named person, "
            "not when they ask about a flight."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": (
                        "Passenger's full or partial name, e.g. 'Roopa Nair' or "
                        "'Roopa'. At least two characters."
                    ),
                }
            },
            "required": ["name"],
        },
    },
    {
        "name": "maintenance_history",
        "description": (
            "Returns the engineering record for one airframe, identified by tail "
            "number: last inspection date, next inspection due, total hours flown, "
            "any open defects with severity, and whether the aircraft is currently "
            "airworthy. Use this to judge whether a specific aircraft can fly. "
            "It takes a tail number such as 'VT-AWA', not a flight number; call "
            "get_flight_status first if you only know the flight."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "tail_number": {
                    "type": "string",
                    "description": (
                        "Aircraft registration in the form 'VT-AWA'. Not a flight "
                        "number and not an aircraft type."
                    ),
                }
            },
            "required": ["tail_number"],
        },
    },
    {
        "name": "find_available_gate",
        "description": (
            "Returns an unoccupied gate in the given terminal, along with every "
            "other free gate and which flights are holding the occupied ones. Use "
            "this when a flight needs to be moved or a new stand assigned. It "
            "reports availability only; it does not reassign anything."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "terminal": {
                    "type": "string",
                    "description": "Terminal identifier, e.g. 'T3' (or just '3').",
                }
            },
            "required": ["terminal"],
        },
    },
    {
        "name": "get_weather",
        "description": (
            "Returns the latest METAR observation for an airport: conditions, "
            "visibility in metres, wind, temperature, and a flag for whether "
            "visibility is below landing minima. Use this to judge departure or "
            "arrival risk. Takes a 3-letter IATA airport code such as 'DEL', not a "
            "city name. The feed can be down, in which case it returns an error."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "airport": {
                    "type": "string",
                    "description": "3-letter IATA airport code, e.g. 'DEL', 'BOM'.",
                }
            },
            "required": ["airport"],
        },
    },
    {
        "name": "lookup_aircraft",
        "description": (
            "Returns the static specification for an aircraft type: manufacturer, "
            "length, wingspan, maximum seats, MTOW, fuel capacity and range. This "
            "is reference data about the model of aircraft, not about any "
            "individual airframe or flight - use maintenance_history for that."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "aircraft_type": {
                    "type": "string",
                    "description": (
                        "Aircraft type designator, e.g. 'A320', 'B737-800', "
                        "'A350-900', 'ATR72-600'."
                    ),
                }
            },
            "required": ["aircraft_type"],
        },
    },
    {
        "name": "remember",
        "description": (
            "Store a fact that persists across sessions. Use this to remember user "
            "preferences (e.g. 'terminal_preference': 'T2'), maintenance notes, or "
            "other operational facts. Storing the same key twice overwrites the old "
            "value with the new one (last-write-wins semantics)."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "key": {
                    "type": "string",
                    "description": "Unique identifier for the fact, e.g. 'terminal_preference'.",
                },
                "value": {
                    "type": "string",
                    "description": "The fact to store, e.g. 'T2' or 'pilot prefers early gates'.",
                },
                "source": {
                    "type": "string",
                    "description": "Who provided this fact, e.g. 'user' or 'agent'. Defaults to 'agent'.",
                },
            },
            "required": ["key", "value"],
        },
    },
    {
        "name": "recall",
        "description": (
            "Retrieve facts from persistent memory by substring search on keys. "
            "Returns all facts whose keys match the query (case-insensitive). "
            "Use this to check what SkyVault already knows before asking the user "
            "to repeat information."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": (
                        "Substring to search for in fact keys, e.g. 'terminal' or 'pilot'."
                    ),
                }
            },
            "required": ["query"],
        },
    },
]

# Exploration in Part 4: the same agent, restricted to a third of its toolset.
MINIMAL_TOOLSET = ["get_flight_status", "get_weather", "maintenance_history"]


def build_declarations(lazy: bool = False, only: list[str] | None = None) -> list[dict]:
    """Return the tool declarations, optionally degraded or restricted.

    lazy: replace get_flight_status's careful description with the useless one.
    only: keep just these tool names, for the "fewer tools" experiment.
    """
    declarations = deepcopy(DECLARATIONS)

    if lazy:
        for declaration in declarations:
            if declaration["name"] == "get_flight_status":
                declaration["description"] = LAZY_FLIGHT_STATUS_DESCRIPTION

    if only:
        wanted = set(only)
        declarations = [d for d in declarations if d["name"] in wanted]

    return declarations
