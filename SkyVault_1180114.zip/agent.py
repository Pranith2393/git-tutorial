"""ROLL NUMBER: 1180114

Parts 3 and 4: the function-calling lifecycle, and the loop around it.

    ask -> model requests a tool -> we run it -> we hand back the result -> repeat
                                                                  -> model answers

The model only ever *asks* for a tool. Every actual execution happens in
tools.run_tool, called from this file. That separation is the entire safety
argument for function calling: the developer owns all side effects.
"""

import time
from dataclasses import dataclass, field

import config
import memory
import planner
import reflector
from mcp_client import MCPClient

def get_system_prompt() -> str:
    """Build the system prompt with current memory loaded in."""
    base = """You are FlightOps, the AI operations officer for AeroWing \
Airlines. You support pilots, dispatchers and the operations desk.

How you work:
- Never state an operational fact you have not read from a tool result. You have \
no memory of today's schedule, weather or maintenance status.
- Chain tools when a question needs it. Judging whether a flight will depart on \
time means checking the departure airport's weather, the flight's own status, and \
the operating aircraft's maintenance record - not just one of the three.
- Tool outputs feed each other. get_flight_status gives you the tail_number that \
maintenance_history needs, and the origin airport that get_weather needs.
- If a tool returns {"status": "error"}, do not retry it more than once and do not \
invent the answer. Tell the user plainly which check could not be completed and \
what that means for the confidence of your answer.
- Answer like an operations professional: lead with the operational bottom line, \
then the evidence behind it. Quote specific figures - times, visibility in metres, \
defect IDs. Keep it under about 150 words.
"""
    memory_summary = memory.load_memory_summary()
    if memory_summary:
        return base + "\n" + memory_summary
    return base


SYSTEM_PROMPT = get_system_prompt()


@dataclass
class ToolInvocation:
    """One completed request/execute cycle, kept for the trace and the reflector."""

    round_number: int
    name: str
    arguments: dict
    result: dict
    duration_ms: float

    @property
    def failed(self) -> bool:
        return self.result.get("status") == "error"


@dataclass
class AgentRun:
    question: str
    plan: planner.Plan | None = None
    answer: str = ""
    tool_calls: list[ToolInvocation] = field(default_factory=list)
    reflection: str = ""
    rounds_used: int = 0
    hit_round_limit: bool = False


class FlightOpsAgent:
    """Holds the model, the MCP client, and the loop that connects them."""

    def __init__(
        self,
        model,
        mcp_client: MCPClient,
        system_prompt: str | None = None,
        max_rounds: int = config.MAX_TOOL_ROUNDS,
        on_event=None,
    ):
        self.model = model
        self.mcp_client = mcp_client
        self.declarations = mcp_client.list_tools()
        self.system_prompt = system_prompt or get_system_prompt()
        self.max_rounds = max_rounds
        # Optional callback so main.py can print the trace as it happens instead
        # of waiting for the run to finish.
        self.on_event = on_event or (lambda event, payload: None)

    def run(self, question: str, plan: bool = True, reflect: bool = True) -> AgentRun:
        """Plan, execute the tool loop, answer, then reflect."""
        outcome = AgentRun(question=question)

        if plan:
            outcome.plan = planner.make_plan(self.model, question, self.declarations)
            self.on_event("plan", outcome.plan)

        self._execute(question, outcome)

        if reflect and outcome.answer:
            outcome.reflection = reflector.reflect(
                self.model, question, outcome.tool_calls, outcome.answer
            )
            self.on_event("reflection", outcome.reflection)

        return outcome

    def _execute(self, question: str, outcome: AgentRun) -> None:
        """The loop from Part 4. Keeps going while the model asks for tools."""
        opening = question
        if outcome.plan and outcome.plan.as_prompt_hint():
            opening = (
                f"{question}\n\n"
                f"[Plan drawn up before execution - follow it where it still makes "
                f"sense, deviate where the tool results say otherwise]\n"
                f"{outcome.plan.as_prompt_hint()}"
            )

        transcript = [{"role": "user", "text": opening}]

        for round_number in range(1, self.max_rounds + 1):
            outcome.rounds_used = round_number

            reply = self.model.respond(
                transcript=transcript,
                declarations=self.declarations,
                system_instruction=self.system_prompt,
            )

            if not reply.wants_tools:
                outcome.answer = reply.text
                self.on_event("answer", outcome.answer)
                return

            # Record the model's turn verbatim, tool requests included - Gemini
            # rejects a function response that is not preceded by its call.
            transcript.append(
                {
                    "role": "model",
                    "text": reply.text,
                    "tool_calls": reply.tool_calls,
                }
            )

            if reply.text:
                self.on_event("thought", reply.text)

            for call in reply.tool_calls:
                self.on_event("tool_request", call)

                started = time.perf_counter()
                try:
                    result = self.mcp_client.call_tool(call.name, call.arguments)
                except RuntimeError as e:
                    result = {"status": "error", "tool": call.name, "message": str(e)}
                elapsed_ms = (time.perf_counter() - started) * 1000

                invocation = ToolInvocation(
                    round_number=round_number,
                    name=call.name,
                    arguments=call.arguments,
                    result=result,
                    duration_ms=elapsed_ms,
                )
                outcome.tool_calls.append(invocation)
                self.on_event("observation", invocation)

                transcript.append(
                    {"role": "tool", "name": call.name, "result": result}
                )

        outcome.hit_round_limit = True
        outcome.answer = self._force_final_answer(transcript)
        self.on_event("answer", outcome.answer)

    def _force_final_answer(self, transcript: list[dict]) -> str:
        """Out of rounds: ask for an answer with the tools taken away."""
        transcript = transcript + [
            {
                "role": "user",
                "text": (
                    "You have used your full budget of tool calls. Answer now using "
                    "only what the tool results above already tell you, and state "
                    "clearly what you could not confirm."
                ),
            }
        ]
        reply = self.model.respond(
            transcript=transcript,
            declarations=None,
            system_instruction=self.system_prompt,
        )
        return reply.text
