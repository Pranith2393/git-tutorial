"""ROLL NUMBER: 1180114

GateBot: a second consumer of the find_available_gate tool via MCP.

This script imports ONLY mcp_client.py, not agent.py or tools.py.
It demonstrates that tools exposed via MCP can be called by any consumer,
not just the agent that exposed them.

The tool was built once in tools.py, registered once in main.py's registry,
and is now reused by a consumer we didn't write - proving the MCP payoff.
"""

import tools
from mcp_server import MCPServer, ToolRegistry
from mcp_client import MCPClient


def main():
    # Build a minimal MCP server with just the gate tool
    registry = ToolRegistry()
    registry.register(
        name="find_available_gate",
        func=tools.find_available_gate,
        description="First unoccupied gate in a terminal, plus any others that are free.",
        parameters={
            "type": "object",
            "properties": {
                "terminal": {
                    "type": "string",
                    "description": "Terminal identifier, e.g. 'T3' (or just '3').",
                }
            },
            "required": ["terminal"],
        },
    )

    server = MCPServer(registry, name="GateBotServer", version="1.0")
    client = MCPClient(server, client_name="GateBot")

    # Call the tool without ever importing agent.py or knowing how it works
    print("GateBot calling find_available_gate for Terminal 2...")
    result = client.call_tool("find_available_gate", {"terminal": "T2"})
    print(f"Result: {result}")

    print("\nAvailable tools on this server:")
    for tool in client.list_tools():
        print(f"  - {tool['name']}: {tool['description']}")


if __name__ == "__main__":
    main()
