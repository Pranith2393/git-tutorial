"""ROLL NUMBER: 1180114

Test script for SkyVault: verify memory + MCP end-to-end.

Demonstrates that:
1. Memory persists across process restarts
2. Recalled facts are loaded into the system prompt
3. Tool calls flow through MCP instead of direct import
4. All JSON-RPC messages are correctly shaped
"""

import json
import os
import tools
import memory
from mcp_server import MCPServer, ToolRegistry
from mcp_client import MCPClient


def log_request_response(request, response, title=""):
    """Pretty-print a JSON-RPC request/response pair."""
    if title:
        print(f"\n{title}")
    print(f"Request:  {json.dumps(request, indent=2)}")
    print(f"Response: {json.dumps(response, indent=2)}")


def test_memory_persistence():
    """Test that memory survives a restart."""
    print("\n" + "="*70)
    print("TEST 1: Memory Persistence")
    print("="*70)

    # Clean up memory file
    memory_file = "memory.json"
    if os.path.exists(memory_file):
        os.remove(memory_file)

    # Simulate Session 1: remember a fact
    print("\nSession 1: User states a preference")
    result = tools.remember(key="terminal_preference", value="T2", source="user")
    print(f"  remember() returned: {result}")

    # Simulate restart: memory should still be there
    print("\nSession 2 (simulated restart):")
    summary = memory.load_memory_summary()
    print(f"  Loaded memory summary:\n{summary}")
    assert "T2" in summary, "Memory was lost across restart!"
    print("  [PASS] Memory persisted")


def test_mcp_protocol():
    """Test that MCP messages are correctly shaped."""
    print("\n" + "="*70)
    print("TEST 2: MCP Protocol Message Shapes")
    print("="*70)

    # Build a minimal MCP server
    registry = ToolRegistry()
    registry.register(
        name="find_available_gate",
        func=tools.find_available_gate,
        description="Test tool",
        parameters={
            "type": "object",
            "properties": {"terminal": {"type": "string"}},
            "required": ["terminal"],
        },
    )
    server = MCPServer(registry, name="SkyVault", version="1.0")

    # Test initialize
    print("\n1. Initialize handshake")
    init_req = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"client_name": "TestClient"}}
    init_resp = server.handle_request(init_req)
    log_request_response(init_req, init_resp, "Initialize:")
    assert init_resp.get("result", {}).get("server_name") == "SkyVault"
    print("  [PASS] Initialize response correct")

    # Test tools/list
    print("\n2. List tools")
    list_req = {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
    list_resp = server.handle_request(list_req)
    log_request_response(list_req, list_resp, "Tools/list:")
    assert len(list_resp.get("result", {}).get("tools", [])) > 0
    print("  [PASS] Tools list returned")

    # Test tools/call success
    print("\n3. Call tool (success)")
    call_req = {
        "jsonrpc": "2.0",
        "id": 3,
        "method": "tools/call",
        "params": {"name": "find_available_gate", "arguments": {"terminal": "T2"}},
    }
    call_resp = server.handle_request(call_req)
    log_request_response(call_req, call_resp, "Tools/call (success):")
    assert "result" in call_resp
    print("  [PASS] Tool executed, result returned")

    # Test tools/call error (unknown tool)
    print("\n4. Call tool (error - unknown tool)")
    error_req = {
        "jsonrpc": "2.0",
        "id": 4,
        "method": "tools/call",
        "params": {"name": "nonexistent_tool", "arguments": {}},
    }
    error_resp = server.handle_request(error_req)
    log_request_response(error_req, error_resp, "Tools/call (error):")
    assert "error" in error_resp
    print("  [PASS] Error response correct")


def test_client_server_integration():
    """Test that client and server communicate correctly."""
    print("\n" + "="*70)
    print("TEST 3: Client-Server Integration")
    print("="*70)

    # Build registry with all tools
    registry = ToolRegistry()
    tool_functions = {
        "get_flight_status": tools.get_flight_status,
        "find_available_gate": tools.find_available_gate,
        "remember": tools.remember,
        "recall": tools.recall,
    }

    # Register just these four for brevity
    for name, func in tool_functions.items():
        registry.register(
            name=name,
            func=func,
            description=f"Tool: {name}",
            parameters={"type": "object", "properties": {}, "required": []},
        )

    server = MCPServer(registry)
    client = MCPClient(server, client_name="TestClient")

    # Test list_tools
    print("\n1. Client requests tool list")
    tools_list = client.list_tools()
    print(f"  Got {len(tools_list)} tools")
    assert len(tools_list) == 4
    print("  [PASS] Tool list received")

    # Test call_tool with remember
    print("\n2. Client calls remember via MCP")
    result = client.call_tool("remember", {"key": "test_fact", "value": "test_value"})
    print(f"  Result: {result}")
    assert result.get("status") == "ok"
    print("  [PASS] Remember tool called through MCP")

    # Test call_tool with recall
    print("\n3. Client calls recall via MCP")
    result = client.call_tool("recall", {"query": "test"})
    print(f"  Result: {result}")
    assert result.get("status") == "ok"
    assert "test_fact" in result.get("matches", {})
    print("  [PASS] Recall tool called through MCP")


def main():
    print("\n" + "="*70)
    print("SkyVault Integration Tests")
    print("="*70)

    test_memory_persistence()
    test_mcp_protocol()
    test_client_server_integration()

    print("\n" + "="*70)
    print("All tests passed!")
    print("="*70)


if __name__ == "__main__":
    main()
