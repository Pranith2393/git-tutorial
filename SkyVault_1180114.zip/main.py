"""ROLL NUMBER: 1180114

FlightOps entry point.

    python main.py                                  interactive session
    python main.py "Is AI203 likely to depart on time?"
    python main.py --demo                           the three scripted scenarios
    python main.py --minimal-tools "..."            only 3 tools available
    python main.py --lazy "..."                     degraded tool description

Run app.py first if you have changed anything in tools.py.
"""

import argparse
import sys

import schemas
import tools
import trace
from agent import FlightOpsAgent
from llm import get_model
from mcp_client import MCPClient
from mcp_server import MCPServer, ToolRegistry

# Scenarios used for the screenshots and the README write-up.
DEMOS = [
    (
        "Multi-tool reasoning (Part 4)",
        "Is AI203 likely to depart on time?",
    ),
    (
        "Graceful tool failure (Part 7)",
        "What is the weather at CCU right now, and is AI556 affected by it?",
    ),
    (
        "Single-tool question",
        "What seat is Roopa Nair in and where is she flying?",
    ),
]

EXIT_COMMANDS = {"/exit", "exit", "quit", "q"}


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="FlightOps",
        description="An AI operations officer that calls AeroWing's internal tools.",
    )
    parser.add_argument(
        "question",
        nargs="*",
        help="Question to answer. Omit for an interactive session.",
    )
    parser.add_argument("--demo", action="store_true", help="Run the scripted scenarios.")
    parser.add_argument("--no-plan", action="store_true", help="Skip the planner.")
    parser.add_argument("--no-reflect", action="store_true", help="Skip the reflector.")
    parser.add_argument(
        "--lazy",
        action="store_true",
        help="Use the deliberately vague get_flight_status description (Part 2).",
    )
    parser.add_argument(
        "--minimal-tools",
        action="store_true",
        help="Expose only 3 of the 6 tools (Part 4 exploration).",
    )
    return parser


def make_event_printer():
    """Route agent events to the trace renderer as the run unfolds."""
    handlers = {
        "plan": trace.show_plan,
        "thought": trace.show_thought,
        "tool_request": trace.show_tool_request,
        "observation": trace.show_observation,
        "answer": trace.show_answer,
        "reflection": trace.show_reflection,
    }

    def handle(event: str, payload) -> None:
        handler = handlers.get(event)
        if handler:
            handler(payload)

    return handle


def ask(agent: FlightOpsAgent, question: str, args) -> None:
    trace.show_question(question)
    run = agent.run(question, plan=not args.no_plan, reflect=not args.no_reflect)
    trace.show_summary(run)


def main() -> None:
    # Model replies contain the odd non-ASCII character; the Windows console
    # default encoding chokes on those.
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    args = build_argument_parser().parse_args()

    # Build the MCP layer: registry -> server -> client
    registry = ToolRegistry()

    # Register all tools from tools.py into the registry
    tool_functions = {
        "get_flight_status": tools.get_flight_status,
        "search_passenger": tools.search_passenger,
        "maintenance_history": tools.maintenance_history,
        "find_available_gate": tools.find_available_gate,
        "get_weather": tools.get_weather,
        "lookup_aircraft": tools.lookup_aircraft,
        "remember": tools.remember,
        "recall": tools.recall,
    }

    declarations = schemas.build_declarations(
        lazy=args.lazy,
        only=schemas.MINIMAL_TOOLSET if args.minimal_tools else None,
    )

    for decl in declarations:
        tool_name = decl["name"]
        if tool_name in tool_functions:
            registry.register(
                name=tool_name,
                func=tool_functions[tool_name],
                description=decl["description"],
                parameters=decl["parameters"],
            )

    server = MCPServer(registry, name="SkyVault", version="1.0")
    client = MCPClient(server, client_name="FlightOps")

    agent = FlightOpsAgent(
        model=get_model(),
        mcp_client=client,
        on_event=make_event_printer(),
    )

    active = ", ".join(d["name"] for d in agent.declarations)
    print(f"FlightOps ready. Tools available: {active}")
    if args.lazy:
        print("Running with the LAZY get_flight_status description.")

    if args.demo:
        for title, question in DEMOS:
            trace.rule(f"### {title}")
            ask(agent, question, args)
        return

    if args.question:
        ask(agent, " ".join(args.question), args)
        return

    print("Type a question, or /exit to quit.")
    while True:
        try:
            question = input("\nops> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nSession ended.")
            return

        if not question:
            continue
        if question.lower() in EXIT_COMMANDS:
            print("Session ended.")
            return

        try:
            ask(agent, question, args)
        except Exception as error:
            # A failed API call should not end the session.
            print(f"\nFlightOps could not complete that request: {error}")


if __name__ == "__main__":
    main()
