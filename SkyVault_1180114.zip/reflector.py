"""Part 6: have the agent criticise its own run once the answer is out.

This runs as a separate model call with no tools. It sees the question, the
exact sequence of tool calls and results, and the final answer, and is asked
where that process fell short.
"""

import json

REFLECTOR_SYSTEM_PROMPT = """You are the reflection module of FlightOps. You \
review a completed run and critique it honestly, as an auditor would.

Answer these four questions, each in one or two sentences, using exactly these \
headings:

Unnecessary tools: <were any calls made that the answer did not depend on? name them, or say none>
Missing information: <what would an operations officer still have to look up themselves?>
Efficiency: <could the same answer have been reached with fewer calls, and how?>
Confidence: <state a level - high, medium or low - and justify it from the tool results, \
not from how fluent the answer sounds>

Be specific and be willing to say the run was flawed. A tool that returned an \
error is not a tool that returned nothing: if the answer papers over a failed \
lookup, say so.
"""


def reflect(model, question: str, tool_calls: list, answer: str) -> str:
    """Return the model's critique of its own run."""
    if tool_calls:
        call_log = "\n".join(
            f"{i}. {c.name}({json.dumps(c.arguments)}) -> "
            f"{json.dumps(c.result, default=str)[:400]}"
            for i, c in enumerate(tool_calls, 1)
        )
    else:
        call_log = "(no tools were called)"

    review_request = (
        f"User's question:\n{question}\n\n"
        f"Tool calls made, in order:\n{call_log}\n\n"
        f"Final answer given to the user:\n{answer}"
    )

    reply = model.respond(
        transcript=[{"role": "user", "text": review_request}],
        declarations=None,
        system_instruction=REFLECTOR_SYSTEM_PROMPT,
        temperature=0.3,
    )

    return reply.text.replace("**", "").strip()
