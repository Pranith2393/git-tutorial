"""ROLL NUMBER: 1180114

MCP Client: send requests to the MCP Server and parse responses.

Clients call list_tools() and call_tool() to interact with tools through
the protocol boundary instead of direct imports.
"""

import json
from typing import Any


class MCPClient:
    """Client for communicating with an MCP Server."""

    def __init__(self, server, client_name: str = "Host"):
        """Initialize the client with a reference to the server.

        Args:
            server: an MCPServer instance
            client_name: name to send during initialize handshake
        """
        self.server = server
        self.client_name = client_name
        self.request_id_counter = 0
        self._initialize()

    def _get_request_id(self) -> int:
        """Generate a unique request ID."""
        self.request_id_counter += 1
        return self.request_id_counter

    def _initialize(self) -> None:
        """Send an initialize request to establish the connection."""
        request = {
            "jsonrpc": "2.0",
            "id": self._get_request_id(),
            "method": "initialize",
            "params": {"client_name": self.client_name},
        }
        response = self.server.handle_request(request)
        if "error" in response:
            raise RuntimeError(f"Initialize failed: {response['error']}")

    def list_tools(self) -> list[dict]:
        """Request the list of available tools from the server.

        Returns:
            list of tool dicts with name, description, parameters
        """
        request = {
            "jsonrpc": "2.0",
            "id": self._get_request_id(),
            "method": "tools/list",
            "params": {},
        }
        response = self.server.handle_request(request)

        if "error" in response:
            raise RuntimeError(f"tools/list failed: {response['error']}")

        return response.get("result", {}).get("tools", [])

    def call_tool(self, name: str, arguments: dict) -> dict:
        """Call a tool on the server.

        Args:
            name: the tool name
            arguments: dict of arguments to pass to the tool

        Returns:
            the tool's result dict

        Raises:
            RuntimeError if the tool is unknown or execution fails
        """
        request = {
            "jsonrpc": "2.0",
            "id": self._get_request_id(),
            "method": "tools/call",
            "params": {"name": name, "arguments": arguments},
        }
        response = self.server.handle_request(request)

        if "error" in response:
            error = response["error"]
            raise RuntimeError(f"Tool {name} failed: {error.get('message', 'unknown error')}")

        return response.get("result", {})
