"""ROLL NUMBER: 1180114

Capture JSON-RPC trace for submission.

Runs a multi-tool scenario through the MCP layer and logs all
request/response pairs to a file.
"""

import json
import tools
from mcp_server import MCPServer, ToolRegistry
from mcp_client import MCPClient


def main():
    # Build the MCP layer
    registry = ToolRegistry()

    tool_functions = {
        "get_flight_status": tools.get_flight_status,
        "search_passenger": tools.search_passenger,
        "maintenance_history": tools.maintenance_history,
        "find_available_gate": tools.find_available_gate,
        "get_weather": tools.get_weather,
        "lookup_aircraft": tools.lookup_aircraft,
        "remember": tools.remember,
        "recall": tools.recall,
    }

    # Tool declarations (from schemas)
    declarations = {
        "get_flight_status": {
            "description": "Returns live operational record for one flight",
            "parameters": {
                "type": "object",
                "properties": {"flight_number": {"type": "string"}},
                "required": ["flight_number"],
            },
        },
        "find_available_gate": {
            "description": "Returns an unoccupied gate in the given terminal",
            "parameters": {
                "type": "object",
                "properties": {"terminal": {"type": "string"}},
                "required": ["terminal"],
            },
        },
    }

    for name, func in tool_functions.items():
        decl = declarations.get(name, {})
        registry.register(
            name=name,
            func=func,
            description=decl.get("description", f"Tool: {name}"),
            parameters=decl.get("parameters", {"type": "object", "properties": {}}),
        )

    server = MCPServer(registry)
    client = MCPClient(server, client_name="FlightOps")

    trace = []

    # Scenario 1: Initialize
    print("Scenario 1: Initialize handshake")
    init_req = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"client_name": "FlightOps"}}
    init_resp = server.handle_request(init_req)
    trace.append({"step": "Initialize", "request": init_req, "response": init_resp})
    print(f"  Request ID: {init_req['id']}, Response: {init_resp.get('result', {}).get('server_name')}")

    # Scenario 2: List tools
    print("\nScenario 2: List available tools")
    list_req = {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
    list_resp = server.handle_request(list_req)
    trace.append({"step": "List tools", "request": list_req, "response": list_resp})
    tool_count = len(list_resp.get("result", {}).get("tools", []))
    print(f"  Request ID: {list_req['id']}, Tools available: {tool_count}")

    # Scenario 3: Call get_flight_status
    print("\nScenario 3: Query flight status")
    flight_req = {
        "jsonrpc": "2.0",
        "id": 3,
        "method": "tools/call",
        "params": {"name": "get_flight_status", "arguments": {"flight_number": "AI203"}},
    }
    flight_resp = server.handle_request(flight_req)
    trace.append({"step": "Get flight status (AI203)", "request": flight_req, "response": flight_resp})
    status = flight_resp.get("result", {}).get("flight_status")
    print(f"  Request ID: {flight_req['id']}, Flight status: {status}")

    # Scenario 4: Call find_available_gate
    print("\nScenario 4: Find available gate")
    gate_req = {
        "jsonrpc": "2.0",
        "id": 4,
        "method": "tools/call",
        "params": {"name": "find_available_gate", "arguments": {"terminal": "T2"}},
    }
    gate_resp = server.handle_request(gate_req)
    trace.append({"step": "Find available gate (T2)", "request": gate_req, "response": gate_resp})
    gate = gate_resp.get("result", {}).get("available_gate")
    print(f"  Request ID: {gate_req['id']}, Available gate: {gate}")

    # Scenario 5: Remember a fact
    print("\nScenario 5: Remember a fact")
    remember_req = {
        "jsonrpc": "2.0",
        "id": 5,
        "method": "tools/call",
        "params": {
            "name": "remember",
            "arguments": {
                "key": "terminal_preference",
                "value": "T2",
                "source": "user",
            },
        },
    }
    remember_resp = server.handle_request(remember_req)
    trace.append({"step": "Remember terminal preference", "request": remember_req, "response": remember_resp})
    print(f"  Request ID: {remember_req['id']}, Message: {remember_resp.get('result', {}).get('message')}")

    # Scenario 6: Recall a fact
    print("\nScenario 6: Recall the remembered fact")
    recall_req = {
        "jsonrpc": "2.0",
        "id": 6,
        "method": "tools/call",
        "params": {"name": "recall", "arguments": {"query": "terminal"}},
    }
    recall_resp = server.handle_request(recall_req)
    trace.append({"step": "Recall terminal preference", "request": recall_req, "response": recall_resp})
    matches = recall_resp.get("result", {}).get("matches", {})
    print(f"  Request ID: {recall_req['id']}, Matches: {matches}")

    # Write trace to file
    trace_file = "jsonrpc_trace.log"
    with open(trace_file, "w") as f:
        f.write("=" * 80 + "\n")
        f.write("JSON-RPC TRACE LOG - SkyVault Multi-Tool Scenario\n")
        f.write("=" * 80 + "\n\n")

        for entry in trace:
            f.write(f"Step: {entry['step']}\n")
            f.write(f"Request:\n{json.dumps(entry['request'], indent=2)}\n\n")
            f.write(f"Response:\n{json.dumps(entry['response'], indent=2)}\n")
            f.write("-" * 80 + "\n\n")

    print(f"\n[OK] Trace saved to {trace_file}")
    return trace_file


if __name__ == "__main__":
    main()
