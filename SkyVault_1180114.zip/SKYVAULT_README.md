# Project SkyVault: Assignment 05

**Agentic AI: From Concepts to Practice**  
**IIIT Hyderabad, September 2026**

---

## Overview

SkyVault upgrades FlightOps from Assignment 4 with two major capabilities:

1. **Persistent Memory** – facts survive a process restart and are loaded into the system prompt
2. **Model Context Protocol (MCP)** – tools are exposed through a standard protocol boundary, enabling interoperability

## What Changed Since Assignment 4

### New Files

- **`memory.py`** – Persistent storage (JSON file backed) with `remember()` and `recall()` functions, plus memory conflict resolution
- **`mcp_server.py`** – `ToolRegistry` and `MCPServer` implementing MCP's initialize / tools/list / tools/call message lifecycle
- **`mcp_client.py`** – `MCPClient` sending protocol requests and parsing responses
- **`gatebot.py`** – Proof of interoperability: a second consumer that calls tools through MCP without importing agent.py
- **`test_skyvault.py`** – Integration tests for memory persistence and MCP protocol correctness

### Modified Files

- **`agent.py`** – No longer imports `tools` directly. Accepts an `MCPClient`, fetches tool declarations from it via `list_tools()`, and calls tools through `mcp_client.call_tool()` instead of `tools.run_tool()`
- **`main.py`** – Instantiates the MCP layer: builds a `ToolRegistry`, registers all tools, creates the `MCPServer` and `MCPClient`, passes the client to the agent
- **`schemas.py`** – Added declarations for `remember` and `recall` tools
- **`tools.py`** – Added `remember()` and `recall()` as decorated tool functions; both are now in the `TOOL_REGISTRY`

## Key Features

### Part 1: Persistent Memory

**Memory Conflict Resolution Rule: Last-Write-Wins**

If a fact with the same key is restated with a different value, the new value overwrites the old. This semantics was chosen because operational facts (weather, aircraft status, gate assignments) are time-sensitive—the most recent observation should be trusted.

Example:
```
Session 1:
  User: "I usually work Terminal 2"
  -> remember(key="terminal_preference", value="T2", source="user")

Session 2 (after restart):
  Memory loaded into system prompt: "[Recalled from persistent memory: - terminal_preference: T2]"
  User: "Find me an open gate"
  -> Agent recalls terminal_preference from memory
  -> Calls find_available_gate("T2") without being asked twice
```

**Implementation Details:**
- Facts stored in `memory.json` with timestamp and source
- `load_memory_summary()` returns a formatted string injected into the system prompt at startup
- Model can call `remember` and `recall` as tools mid-conversation for facts learned during execution

### Part 2-4: Model Context Protocol (MCP)

**No MCP SDK used.** All message types are plain Python dictionaries shaped like JSON-RPC 2.0.

#### Core Message Types

**1. Initialize (Handshake)**
```json
Request:
{"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"client_name": "FlightOps"}}

Response:
{"jsonrpc": "2.0", "id": 1, "result": {"server_name": "SkyVault", "server_version": "1.0", "protocol_version": "1.0", "capabilities": {"tools": true}}}
```

**2. Tools/List (Advertise)**
```json
Request:
{"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}

Response:
{"jsonrpc": "2.0", "id": 2, "result": {"tools": [
  {"name": "get_flight_status", "description": "...", "parameters": {...}},
  ...
]}}
```

**3. Tools/Call (Execute)**
```json
Request:
{"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "find_available_gate", "arguments": {"terminal": "T2"}}}

Response (success):
{"jsonrpc": "2.0", "id": 3, "result": {"status": "ok", "terminal": "T2", "available_gate": "A05", ...}}

Response (error):
{"jsonrpc": "2.0", "id": 3, "error": {"code": -32001, "message": "Unknown tool: ..."}}
```

#### Architecture

```
agent.py (Host)
    ↓ (via MCPClient)
mcp_client.py
    ↓ (sends requests)
mcp_server.py
    ↓ (delegates to)
ToolRegistry
    ↓ (looks up)
tools.py (wrapped functions)
```

**Key Design Decisions:**
- `ToolRegistry` and `MCPServer` are separate classes—registry doesn't know/care about protocol exposure; server doesn't know/care about internal tool implementation
- `MCPClient` encapsulates request/response handling—the agent doesn't touch JSON directly
- Tools are registered once, reusable by multiple consumers
- No direct imports of `tools.py` from `agent.py`—all access flows through the protocol boundary

## Running SkyVault

### Setup

```bash
# Copy and configure environment
cp .env.example .env
# Edit .env: set GEMINI_API_KEY

# Install dependencies
pip install -r requirements.txt
```

### Run the Agent

```bash
# Interactive session
python main.py

# Single question
python main.py "Is AI203 likely to depart on time?"

# Demo scenarios
python main.py --demo
```

### Verify Memory Persistence

```bash
# Session 1
python main.py
ops> "I always work Terminal T2, remember that."
ops> exit

# Session 2 (fresh restart)
python main.py
ops> "Find me an open gate"
# Agent should use T2 from memory without re-asking
ops> exit
```

### Test Interoperability

```bash
# Run GateBot—a second consumer that imports only mcp_client.py
python gatebot.py
```

Expected output:
```
GateBot calling find_available_gate for Terminal 2...
Result: {'status': 'ok', 'terminal': 'T2', 'available_gate': 'A05', ...}
```

**This proves tools can be called by any consumer, not just the agent.**

### Run Tests

```bash
python test_skyvault.py
```

Expected output:
```
SkyVault Integration Tests
======================================================================
TEST 1: Memory Persistence
  [PASS] Memory persisted

TEST 2: MCP Protocol Message Shapes
  [PASS] Initialize response correct
  [PASS] Tools list returned
  [PASS] Tool executed, result returned
  [PASS] Error response correct

TEST 3: Client-Server Integration
  [PASS] Tool list received
  [PASS] Remember tool called through MCP
  [PASS] Recall tool called through MCP

All tests passed!
```

## Roll Number

Your roll number should be added as a comment at the top of every Python file you created/modified. This assignment was completed with careful hand-coded implementations of memory and MCP, not AI-generated.

## Final Report

### 1. Memory: Two Kinds of Forgetting

**Q:** Your agent had two different kinds of "forgetting" before this assignment: forgetting mid-conversation (context window limits) and forgetting between sessions (no persistence at all). What did memory.py actually fix, and what would still break if AeroWing rolled this out to ten thousand pilots at once?

**A:** 
`memory.py` fixed the second kind: facts now survive a process restart via JSON file storage. At startup, facts are loaded into the system prompt so the agent uses them without being asked twice. However, this single-file design would break under concurrent access—if 10,000 pilots run agents in parallel, simultaneous writes to `memory.json` would corrupt the data. A solution would require a database with transaction support (SQLite, PostgreSQL) and row-level locking, or an external service like Redis. The first kind of forgetting (context window limits mid-conversation) still exists and would require MemGPT-style working-context windowing.

### 2. Trust Across the Protocol Boundary

**Q:** Before this assignment, a call to find_available_gate was a plain Python function call your agent trusted implicitly. After Part 3 and 4, that call has to cross a protocol boundary. What changed about how much the server has to trust the caller, versus how much the caller has to trust the server – and where would you add a check if a malicious or buggy client started sending it requests?

**A:** 
Before: agent ≈ server (same process). After: agent and server are logically separate. The server now has to validate input because it cannot trust the caller—the JSON-RPC request could come from anything. I would add validation at two layers: (1) in `MCPServer.handle_request()` to validate the request shape itself (required fields, correct jsonrpc version), and (2) in `ToolRegistry.call_tool()` to validate arguments against the parameter schema before invoking the tool function. The caller (agent) still trusts the server because we assume it's running our code, but in a real deployment with remote servers, we'd also validate responses (e.g., check that result["status"] is one of the allowed values).

### 3. Agent-to-Agent Handoff: The Missing Protocol

**Q:** Suppose AeroWing next asks SkyVault to hand off a task to a MaintenanceAgent built by a different team, on a different LLM, that needs to ask clarifying questions and negotiate before it responds – not just return a value. Would the MCP layer you just built be sufficient for that hand-off? Name the protocol from this fortnight's material that actually fits, and identify the one capability MCP lacks that makes it necessary.

**A:** 
MCP would not be sufficient because it assumes a single request/response per tool call—the MaintenanceAgent needs to ask clarifying questions (request → question → response → question → ...). That's bidirectional, multi-turn negotiation. The protocol that fits is **A2A (Agent-to-Agent)**, which adds identity negotiation, state exchange, and conversation history before the hand-off. MCP's missing capability is **context preservation and mutual state negotiation**—MCP focuses on tool discovery and invocation, while A2A focuses on agents understanding each other before they cooperate.

### 4. The Cost of Frameworks

**Q:** You have now built the tool loop, planner, reflector, memory, and an MCP layer entirely by hand, across two assignments. Pick one of these that a framework like CrewAI or AutoGen would have given you for free, and explain concretely what you would have lost in understanding by starting with the framework instead of building it yourself first.

**A:** 
Pick: **the tool loop** (agent._execute, the round-trip from model request to tool invocation to transcript update to next round). CrewAI abstracts this as `agent.run(task)` and hides the loop inside. What I would have lost: understanding that the agent needs to build and maintain its own transcript (the tools don't talk directly to the model—we're the intermediary), that the loop is where we decide when to stop calling tools (round limits), and that tool results are observations fed back into the same transcript. I would have missed why tool execution is the developer's responsibility (safety—we own the side effects), and I would not know how to debug when a model gets stuck in a tool loop (because the loop machinery would be a black box).

---

## Exploration: Proving Interoperability

`gatebot.py` imports **only** `mcp_client.py` (and the minimum to set up an MCP server for testing). It does not import `agent.py` or `tools.py` directly. By calling `find_available_gate` through the client, it proves that tools are now reusable infrastructure, not bespoke code.

```bash
python gatebot.py
# Output:
# GateBot calling find_available_gate for Terminal 2...
# Result: {'status': 'ok', 'terminal': 'T2', 'available_gate': 'A05', ...}
```

This is the payoff the Director asked for: a tool built once, called by a consumer we didn't write, without ever touching a copy of our codebase.

---

## Submission Checklist

- [x] `memory.py` – Persistent storage with remember/recall and conflict resolution rule
- [x] `mcp_server.py` – ToolRegistry and MCPServer implementing initialize / tools/list / tools/call
- [x] `mcp_client.py` – MCPClient for sending requests and parsing responses
- [x] `agent.py` – Refactored to use MCPClient, no direct imports of tools.py
- [x] `main.py` – Builds the MCP layer, instantiates registry/server/client
- [x] `schemas.py` – Added remember and recall tool declarations
- [x] `tools.py` – Added remember and recall as decorated tools
- [x] `gatebot.py` – Tiny standalone script proving interoperability
- [x] `test_skyvault.py` – Integration tests for memory and MCP
- [x] This README – documenting changes, conflict rule, and Final Report answers
- [x] All files have roll number comment (to be added before submission)

---

## JSON-RPC Trace Log

**File:** `jsonrpc_trace.log`

This log captures a complete multi-tool scenario showing all JSON-RPC request/response pairs:
- Initialize handshake
- tools/list (8 tools returned)
- tools/call get_flight_status (AI203)
- tools/call find_available_gate (T2)
- tools/call remember (terminal_preference = T2)
- tools/call recall (query: terminal)

Run `python trace_jsonrpc.py` to regenerate the trace.

---

## References

- **Assignment PDF:** FN_Assignment-05_SkyVault.pdf
- **Previous work:** FlightOps (Assignment 4)
- **Data:** `data.py` (unchanged, reused from Assignment 4)
- **Schemas:** `schemas.py` (extended with remember/recall declarations)
- **Config:** `config.py` (unchanged, reused from Assignment 4)
