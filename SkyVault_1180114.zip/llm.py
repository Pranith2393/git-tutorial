"""The only file that knows which model provider we are using.

Everything above this layer speaks in two neutral shapes:

  transcript messages   {"role": "user"  , "text": "..."}
                        {"role": "model" , "text": "...", "tool_calls": [...]}
                        {"role": "tool"  , "name": "...", "result": {...}}

  ModelReply            .text  and  .tool_calls

Porting FlightOps to OpenAI or Anthropic means writing one more class with a
`respond` method and returning it from get_model(). agent.py, planner.py and
reflector.py would not change.
"""

from dataclasses import dataclass, field
from typing import Any

from google import genai
from google.genai import types

import config


@dataclass
class ToolCall:
    """A request from the model to run one function. We decide whether to obey."""

    name: str
    arguments: dict[str, Any]
    thought_signature: bytes | None = None


@dataclass
class ModelReply:
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)

    @property
    def wants_tools(self) -> bool:
        return bool(self.tool_calls)


class GeminiModel:
    """Thin adapter over google-genai."""

    def __init__(self, model: str | None = None):
        self.model = model or config.MODEL
        self._client = genai.Client(api_key=config.require_api_key())

    def respond(
        self,
        transcript: list[dict],
        declarations: list[dict] | None = None,
        system_instruction: str | None = None,
        temperature: float = 0.0,
    ) -> ModelReply:
        """Send the conversation to Gemini and normalise whatever comes back."""
        settings: dict[str, Any] = {"temperature": temperature}

        if system_instruction:
            settings["system_instruction"] = system_instruction

        if declarations:
            settings["tools"] = [types.Tool(function_declarations=declarations)]
            # The SDK will happily execute Python callables for us. We turn that
            # off: the whole point of this assignment is that our code, not the
            # library and not the model, decides what actually runs.
            settings["automatic_function_calling"] = (
                types.AutomaticFunctionCallingConfig(disable=True)
            )

        response = self._client.models.generate_content(
            model=self.model,
            contents=_to_gemini_contents(transcript),
            config=types.GenerateContentConfig(**settings),
        )

        return _to_model_reply(response)


def get_model(model: str | None = None):
    """Return the configured provider's adapter."""
    if config.PROVIDER != "gemini":
        raise SystemExit(
            f"LLM_PROVIDER={config.PROVIDER!r} is not implemented. "
            "Only 'gemini' is wired up; add an adapter class in llm.py to support another."
        )
    return GeminiModel(model)


def _to_gemini_contents(transcript: list[dict]) -> list[types.Content]:
    """Translate the neutral transcript into Gemini's Content/Part objects."""
    contents: list[types.Content] = []

    for message in transcript:
        role = message["role"]

        if role == "user":
            contents.append(
                types.Content(
                    role="user",
                    parts=[types.Part.from_text(text=message["text"])],
                )
            )

        elif role == "model":
            parts = []
            if message.get("text"):
                parts.append(types.Part.from_text(text=message["text"]))
            for call in message.get("tool_calls", []):
                part = types.Part.from_function_call(
                    name=call.name, args=call.arguments
                )
                if call.thought_signature:
                    part.thought_signature = call.thought_signature
                parts.append(part)
            if parts:
                contents.append(types.Content(role="model", parts=parts))

        elif role == "tool":
            # Gemini expects tool results back under the "user" role.
            contents.append(
                types.Content(
                    role="user",
                    parts=[
                        types.Part.from_function_response(
                            name=message["name"],
                            response=message["result"],
                        )
                    ],
                )
            )

        else:
            raise ValueError(f"Unknown transcript role: {role!r}")

    return contents


def _to_model_reply(response) -> ModelReply:
    """Pull text and function calls out of a Gemini response."""
    reply = ModelReply()

    candidates = getattr(response, "candidates", None) or []
    if not candidates:
        return reply

    content = candidates[0].content
    if content is None or not content.parts:
        return reply

    text_fragments = []
    for part in content.parts:
        if getattr(part, "thought", False):
            continue
        if getattr(part, "function_call", None):
            call = part.function_call
            reply.tool_calls.append(
                ToolCall(
                    name=call.name,
                    arguments=dict(call.args or {}),
                    thought_signature=getattr(part, "thought_signature", None),
                )
            )
        elif getattr(part, "text", None):
            text_fragments.append(part.text)

    reply.text = "".join(text_fragments).strip()
    return reply
