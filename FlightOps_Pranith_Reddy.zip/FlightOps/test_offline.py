"""Offline check of the agent loop, with a scripted stand-in for the model.

No API key and no network. The point is to prove the plumbing - tool dispatch,
transcript construction, multi-round chaining, structured errors, planner and
reflector wiring - independently of whatever the real model decides to do.

    python test_offline.py
"""

import schemas
import trace
from agent import FlightOpsAgent
from llm import ModelReply, ToolCall


class ScriptedModel:
    """Replays a fixed sequence of tool calls, then a final answer."""

    def __init__(self, script: list[list[ToolCall]], final_answer: str, plan: str):
        self.script = script
        self.final_answer = final_answer
        self.plan = plan
        self.turns = 0

    def respond(self, transcript, declarations=None, system_instruction=None,
                temperature=0.0):
        # Planner and reflector call us with no tools attached.
        if declarations is None:
            if "planning module" in (system_instruction or ""):
                return ModelReply(text=self.plan)
            return ModelReply(text=_canned_reflection(self.script))

        if self.turns < len(self.script):
            calls = self.script[self.turns]
            self.turns += 1
            return ModelReply(text="", tool_calls=calls)

        return ModelReply(text=self.final_answer)


def _canned_reflection(script) -> str:
    planned = [call.name for round_calls in script for call in round_calls]
    return (
        "Unnecessary tools: None; every call fed the conclusion.\n"
        f"Missing information: nothing beyond what {', '.join(planned)} returned.\n"
        f"Efficiency: {len(planned)} call(s) is the minimum for this question.\n"
        "Confidence: Medium - this is a scripted offline run, not a live model."
    )


def run_case(title: str, question: str, script, final_answer: str, plan: str):
    trace.rule(f"### {title}")
    trace.show_question(question)

    agent = FlightOpsAgent(
        model=ScriptedModel(script, final_answer, plan),
        declarations=schemas.build_declarations(),
        on_event=_printer(),
    )
    run = agent.run(question)
    trace.show_summary(run)
    return run


def _printer():
    handlers = {
        "plan": trace.show_plan,
        "tool_request": trace.show_tool_request,
        "observation": trace.show_observation,
        "answer": trace.show_answer,
        "reflection": trace.show_reflection,
    }
    return lambda event, payload: handlers.get(event, lambda _: None)(payload)


def main() -> None:
    happy = run_case(
        title="Three-tool chain",
        question="Is AI203 likely to depart on time?",
        script=[
            [ToolCall("get_flight_status", {"flight_number": "AI203"})],
            [ToolCall("get_weather", {"airport": "DEL"})],
            [ToolCall("maintenance_history", {"tail_number": "VT-AWA"})],
        ],
        final_answer=(
            "Unlikely to depart on schedule. AI203 is still listed as Scheduled for "
            "14:20 off gate B12, but DEL is reporting dense fog with 550 m visibility, "
            "below the 800 m CAT I minimum. VT-AWA itself is airworthy; the only open "
            "item, MX-4417, is a deferred APU bleed valve and is not grounding. "
            "Weather is the constraint, not the aircraft."
        ),
        plan=(
            "Goal: Determine whether AI203 can depart on schedule.\n"
            "Plan:\n"
            "1. Pull the flight record for AI203 (get_flight_status).\n"
            "2. Check departure airport weather (get_weather).\n"
            "3. Check the airframe's open defects (maintenance_history).\n"
            "4. Combine the three into a departure assessment."
        ),
    )

    failing = run_case(
        title="Failing tool handled gracefully",
        question="What is the weather at CCU, and is AI556 affected?",
        script=[
            [ToolCall("get_weather", {"airport": "CCU"})],
            [ToolCall("get_flight_status", {"flight_number": "AI556"})],
        ],
        final_answer=(
            "I could not retrieve CCU weather - the METAR feed did not respond, so "
            "treat this as unverified. AI556 has already departed CCU for IXB at "
            "09:15 with no delay recorded, so any current conditions there no longer "
            "affect its departure."
        ),
        plan=(
            "Goal: Report current CCU conditions and their effect on AI556.\n"
            "Plan:\n"
            "1. Read the CCU observation (get_weather).\n"
            "2. Read AI556's current status (get_flight_status).\n"
            "3. State the impact, flagging anything that could not be verified."
        ),
    )

    bad_arguments = run_case(
        title="Model sends a malformed argument",
        question="Pull the maintenance record for the aircraft on flight AI203.",
        script=[[ToolCall("maintenance_history", {"tail_number": "AI203"})]],
        final_answer=(
            "That lookup failed: AI203 is a flight number, not a tail number. The "
            "airframe on AI203 is VT-AWA - re-running against that registration "
            "would return the record."
        ),
        plan=(
            "Goal: Retrieve the maintenance record for the airframe flying AI203.\n"
            "Plan:\n"
            "1. Resolve AI203 to a tail number (get_flight_status).\n"
            "2. Pull that airframe's record (maintenance_history)."
        ),
    )

    trace.rule("### ASSERTIONS")
    assert len(happy.tool_calls) == 3, "expected a three-tool chain"
    assert all(not c.failed for c in happy.tool_calls), "no tool should have failed"
    assert happy.plan and happy.plan.steps, "planner produced no steps"
    assert happy.reflection, "reflector produced nothing"

    assert failing.tool_calls[0].failed, "CCU weather should return a structured error"
    assert failing.tool_calls[0].result["status"] == "error"
    assert not failing.tool_calls[1].failed, "the run should continue after a failure"

    assert bad_arguments.tool_calls[0].failed, "a flight number is not a valid tail"

    print("All offline assertions passed.")
    print("The loop, the error path and the planner/reflector wiring are sound.")
    print("Run 'python main.py --demo' with a real API key for the graded screenshots.")


if __name__ == "__main__":
    main()
