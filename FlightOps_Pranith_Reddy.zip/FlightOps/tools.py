"""The tools FlightOps is allowed to call.

Every tool is an ordinary Python function that returns a JSON-serialisable dict
with a "status" key of either "ok" or "error". The model never runs any of this;
agent.py does, and then hands the dict back as a tool result.

Returning errors instead of raising them is deliberate. A traceback kills the
agent loop, whereas {"status": "error", ...} is just another observation the
model can read and explain to the user (Part 7).
"""

import re
from functools import wraps

from data import (
    AIRCRAFT,
    FLIGHTS,
    GATES,
    MAINTENANCE,
    PASSENGERS,
    WEATHER,
    WEATHER_SERVICE_OUTAGE,
)

TAIL_NUMBER_PATTERN = re.compile(r"^[A-Z]{1,2}-[A-Z]{3}$")


class ToolError(Exception):
    """A failure the tool anticipated and wants to report in plain language."""


def tool(func):
    """Convert any exception escaping a tool into a structured error result."""

    @wraps(func)
    def wrapper(**kwargs):
        try:
            return func(**kwargs)
        except ToolError as exc:
            return {"status": "error", "tool": func.__name__, "message": str(exc)}
        except Exception as exc:  # never let a tool bug take the agent down
            return {
                "status": "error",
                "tool": func.__name__,
                "message": f"{func.__name__} failed unexpectedly: {exc}",
            }

    return wrapper


@tool
def get_flight_status(flight_number: str) -> dict:
    """Current status, gate and delay for one flight."""
    key = flight_number.strip().upper().replace(" ", "")
    flight = FLIGHTS.get(key)
    if flight is None:
        raise ToolError(
            f"No flight {key} in today's schedule. "
            f"Known flights: {', '.join(sorted(FLIGHTS))}."
        )

    return {
        "status": "ok",
        "flight_number": flight["flight_number"],
        "flight_status": flight["status"],
        "origin": flight["origin"],
        "destination": flight["destination"],
        "scheduled_departure": flight["scheduled_departure"],
        "estimated_departure": flight["estimated_departure"],
        "delay_minutes": flight["delay_minutes"],
        "gate": flight["gate"],
        "terminal": flight["terminal"],
        "tail_number": flight["tail_number"],
        "aircraft_type": flight["aircraft_type"],
    }


@tool
def search_passenger(name: str) -> dict:
    """Booking reference, seat and destination for a passenger, by full or partial name."""
    needle = name.strip().lower()
    if len(needle) < 2:
        raise ToolError("Give at least two characters of the passenger's name.")

    matches = [p for p in PASSENGERS if needle in p["name"].lower()]
    if not matches:
        raise ToolError(f"No passenger on today's manifests matches '{name}'.")

    return {"status": "ok", "match_count": len(matches), "passengers": matches}


@tool
def maintenance_history(tail_number: str) -> dict:
    """Inspection dates, hours flown and open defects for one airframe."""
    tail = tail_number.strip().upper()
    if not TAIL_NUMBER_PATTERN.match(tail):
        raise ToolError(
            f"'{tail_number}' is not a valid tail number. "
            "Expected a registration such as VT-AWA."
        )

    record = MAINTENANCE.get(tail)
    if record is None:
        raise ToolError(f"No maintenance record on file for {tail}.")

    grounding_issues = [i for i in record["open_issues"] if i["grounding"]]
    return {
        "status": "ok",
        "tail_number": record["tail_number"],
        "aircraft_type": record["aircraft_type"],
        "last_inspection": record["last_inspection"],
        "next_inspection_due": record["next_inspection_due"],
        "hours_flown": record["hours_flown"],
        "open_issues": record["open_issues"],
        "airworthy": record["airworthy"],
        "grounding_issue_count": len(grounding_issues),
    }


@tool
def find_available_gate(terminal: str) -> dict:
    """First unoccupied gate in a terminal, plus any others that are free."""
    key = terminal.strip().upper()
    if not key.startswith("T"):
        key = f"T{key}"

    gates = GATES.get(key)
    if gates is None:
        raise ToolError(
            f"Unknown terminal '{terminal}'. Valid terminals: {', '.join(sorted(GATES))}."
        )

    free = sorted(gate for gate, occupant in gates.items() if occupant is None)
    if not free:
        raise ToolError(f"Every gate in {key} is currently occupied.")

    return {
        "status": "ok",
        "terminal": key,
        "available_gate": free[0],
        "all_available_gates": free,
        "occupied_gates": {g: o for g, o in gates.items() if o},
    }


def _fetch_weather_feed(airport: str) -> dict:
    """Pretend network call to the METAR provider. Raises when the feed is down."""
    if airport in WEATHER_SERVICE_OUTAGE:
        raise ConnectionError(f"METAR feed for {airport} did not respond")
    return WEATHER[airport]


@tool
def get_weather(airport: str) -> dict:
    """Visibility, wind and temperature at an airport, from the METAR feed."""
    code = airport.strip().upper()
    if len(code) != 3:
        raise ToolError(f"'{airport}' is not a 3-letter IATA airport code.")
    if code not in WEATHER and code not in WEATHER_SERVICE_OUTAGE:
        raise ToolError(f"No weather station configured for {code}.")

    try:
        reading = _fetch_weather_feed(code)
    except ConnectionError as exc:
        raise ToolError(f"Weather service unavailable for {code}: {exc}") from exc

    low_visibility = reading["visibility_m"] < 800
    return {
        "status": "ok",
        **reading,
        "low_visibility": low_visibility,
        "note": (
            "Visibility below the 800 m CAT I landing minimum; expect departure "
            "delays and possible diversions."
            if low_visibility
            else "Within normal operating minima."
        ),
    }


@tool
def lookup_aircraft(aircraft_type: str) -> dict:
    """Dimensions, seating and fuel figures for an aircraft type."""
    key = aircraft_type.strip().upper().replace(" ", "")
    record = AIRCRAFT.get(key)
    if record is None:
        raise ToolError(
            f"No specification on file for '{aircraft_type}'. "
            f"Known types: {', '.join(sorted(AIRCRAFT))}."
        )
    return {"status": "ok", **record}


# The agent looks tools up by the exact name used in the schema declarations.
TOOL_REGISTRY = {
    "get_flight_status": get_flight_status,
    "search_passenger": search_passenger,
    "maintenance_history": maintenance_history,
    "find_available_gate": find_available_gate,
    "get_weather": get_weather,
    "lookup_aircraft": lookup_aircraft,
}


def run_tool(name: str, arguments: dict) -> dict:
    """Execute a tool by name. Unknown names and bad arguments become error results."""
    func = TOOL_REGISTRY.get(name)
    if func is None:
        return {
            "status": "error",
            "message": f"No tool named '{name}'. Available: {', '.join(TOOL_REGISTRY)}.",
        }

    try:
        return func(**arguments)
    except TypeError as exc:
        # Fires when the model sends an argument the function does not accept,
        # which is exactly what a schema/implementation mismatch looks like.
        return {
            "status": "error",
            "tool": name,
            "message": f"Bad arguments for {name}: {exc}",
        }
